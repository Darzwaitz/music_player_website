# music_player_website
A website for a client with the main functionality being a music player
- The website will use jQuery with Vanilla JS also
